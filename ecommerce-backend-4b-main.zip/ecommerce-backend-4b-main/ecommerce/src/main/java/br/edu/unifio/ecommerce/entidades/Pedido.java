package br.edu.unifio.ecommerce.entidades;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter

public class Pedido {

   @Id
   @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Integer id;
   
   private LocalDateTime data;
   private String status;
   private BigDecimal valortotal;
   
    @ManyToOne 
    @JoinColumn (name = "cliente_id")
    private Cliente cliente;
    
}
